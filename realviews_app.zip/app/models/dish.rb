class Dish < ApplicationRecord
    belongs_to :restaurant
end
